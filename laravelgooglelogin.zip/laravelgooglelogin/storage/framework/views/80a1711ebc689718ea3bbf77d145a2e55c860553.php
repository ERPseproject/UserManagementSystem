<?php $__env->startSection('content'); ?>

<div class="container-fluid ">
  <div class="row content">
    <div class="col-sm-2 sidenav">
      <h4>
        <p><a href="./moufirst">หน้าแรกระบบ</a><br></p>
      </h4>
      <h5>
        <p><a href="search_service"> Search page</a></p>
      </h5>
      <h5>
        <p><a href="service_view"> viewdata page</a></p>
      </h5>
    </div>



    <div class="col-sm-8 main">
      <div class="w3-row w3-padding-64">
        <div class="w3-twothird w3-container">
          <h1 class="w3-text-teal">Search</h1>
          <div class="topnav">
            <a class="active"></a>
            <div class="search-container">
              <form action="/action_page.php">
                <input type="text" placeholder="Search.." name="search">

              </form>

            </div>
          </div>



        </div>
      </div>
    </div>
    <div class="col-sm-2 sidenav"></div>
  </div>


  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('footer'); ?>
  <p>footer</p>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Service_app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>