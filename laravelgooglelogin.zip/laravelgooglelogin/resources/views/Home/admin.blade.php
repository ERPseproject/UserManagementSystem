<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin</title>
    <meta charset="utf-8">
    <link href="css/Admin_index/admin.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>

<header>

    <body>

        <!-- nav bar -->
        <nav class="navbar navbar-inverse navbar-fixed-top" style="background-color: #8B0000;">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Logo Web</a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="./index">Home</a></li>

                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                    </ul>
                </div>
            </div>
        </nav>


        <div class="main">
            <div class="container-fluid text-center">
                <div class="row content">
                    <div class="col-sm-2 sidenav">
                        <button><a></a></button>
                    </div>
                    <div class="col-sm-8 text-left">
                        <br>
                        <h1>Admin</h1>
                        <div class="container-fluid">
                            <table>
                                <tr>
                                    <th>Name</th>
                                    <th>Project & Service</th>
                                    <th>Machine</th>
                                    <th>Research</th>
                                </tr>
                                <tr>
                                    <td>Nuttapol K</td>
                                    <td><input type="checkbox" name="name1" />&nbsp;</td>
                                    <td><input type="checkbox" name="name2" />&nbsp;</td>
                                    <td><input type="checkbox" name="name1" />&nbsp;</td>

                                </tr>
                                <tr>
                                    <td>Lightning</td>
                                    <td><input type="checkbox" name="name1" />&nbsp;</td>
                                    <td><input type="checkbox" name="name2" />&nbsp;</td>
                                    <td><input type="checkbox" name="name1" />&nbsp;</td>

                                </tr>
                                <tr>
                                    <td>Anan</td>
                                    <td><input type="checkbox" name="name1" />&nbsp;</td>
                                    <td><input type="checkbox" name="name2" />&nbsp;</td>
                                    <td><input type="checkbox" name="name1" />&nbsp;</td>

                                </tr>
                                <tr>
                                    <td>Ruj Dumrong</td>
                                    <td><input type="checkbox" name="name1" />&nbsp;</td>
                                    <td><input type="checkbox" name="name2" />&nbsp;</td>
                                    <td><input type="checkbox" name="name1" />&nbsp;</td>

                                </tr>
                                <tr>
                                    <td>Korawit Eiansuk</td>
                                    <td><input type="checkbox" name="name1" />&nbsp;</td>
                                    <td><input type="checkbox" name="name2" />&nbsp;</td>
                                    <td><input type="checkbox" name="name1" />&nbsp;</td>

                                </tr>
                                <tr>
                                    <td>Ruttini Lmao</td>
                                    <td><input type="checkbox" name="name1" />&nbsp;</td>
                                    <td><input type="checkbox" name="name2" />&nbsp;</td>
                                    <td><input type="checkbox" name="name1" />&nbsp;</td>

                                </tr>

                                <tr>
                                    <td> </td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                </tr>


                                <tr>
                                    <td> </td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                </tr>


                                <tr>
                                    <td> </td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                </tr>


                                <tr>
                                    <td> </td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                </tr>


                                <tr>
                                    <td> </td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                </tr>


                                <tr>
                                    <td> </td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                </tr>

                                <tr>
                                    <td> </td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>

                                </tr>

                                <tr>
                                    <td> </td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>

                                </tr>

                                <tr>
                                    <td> </td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>

                                </tr>
                            </table>
                            <div class="Nga">
                          <button type="button" class="btn btn-default">Confirm</button>
                            </div>
                        </div>
                        <!-- <div class="dropdown">
  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Dropdown Example
  <span class="caret"></span></button>
  <ul class="dropdown-menu">
    <li><a href="#">ระบบครุภัณฑ์</a></li>
    <li><a href="#">ระบบวารสาร</a></li>
    <li><a href="#">ระบบบริการ&บริหาร</a></li>
  </ul>
</div> -->
                    </div>
                    <div class="col-sm-2 sidenav"></div>
                </div>
            </div>


            <footer class="container-fluid text-center">
                <p>Footer Text</p>
            </footer>

    </body>
</header>

</html>
