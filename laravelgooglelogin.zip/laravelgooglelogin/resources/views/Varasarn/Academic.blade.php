@extends('layouts.Varasan_app')
@section('content')



<div class="container-fluid text-center">
    <div class="row content">
        <div class="col-sm-2 sidenav">
        <h4>
                <p><a href="./moufirst">หน้าแรกระบบ</a><br></p>
            </h4>
        </div>
        <div class="col-sm-8 main">
            <h1>ประชุมวิขาการ</h1>
            <br>
            <p>ชื่อผู้รับผิดชอบ</p>
            <select name="departcity" id="departcity" onchange="dispterminal(this.value,'departterminal')" class="form-control-search">
                <option value="">--กรุณาเลือก--</option>
                <option value="Professor A">Firstname Lastname</option>
                <option value="Professor B">Firstname Lastname</option>
                <option value="Professor C">Firstname Lastname</option>
                <option value="Professor D">Firstname Lastname</option>
            </select>
            <br>
            <p>ปี ค.ศ.</p>
            <div>
                <input class="form-control-search">
            </div>
            <br>
            <p>ชื่อการประชุม</p>
            <div>
                <input class="form-control-search">
            </div>

            <br>

            <p>สถานที่</p>
            <div>
                <input class="form-control-search">
            </div>

            <br>

            <p>เรื่อง</p>
            <div>
                <input class="form-control-search">
            </div>

            <br>

            <p>ประเทศ</p>
            <div>
                <input class="form-control-search">
            </div>

            <br>

            <p>upload paper</p>
            <div>
                <input type="file" value="เลือกไฟล์" class="form-control-search">
            </div>

            <br>
            <input type="submit" value="ยืนยันการส่งข้อมูล">
        </div>
        <div class="col-sm-2 sidenav"></div>
    </div>
</div>

@endsection

@section('footer')

@endsection