@extends('layouts.Project_app')
@section('content')



   
        <div class="container-fluid ">
            <div class="row content">
                <div class="col-sm-2 sidenav">
                <h4>
                <p><a href="./moufirst">หน้าแรกระบบ</a><br></p>
            </h4>
                </div>



                <div class="col-sm-8 main">
                  <div class="w3-row w3-padding-64">
                    <div class="w3-twothird w3-container">
                      <h2>ค้นหาข้อมูลโครงการ</h2> <br>
                      <article>
                        <div class="card">
                          <h1>โครงการบ้านนี้มีรัก</h1>
                          <p>หัวหน้าโครงการ นาย ธีรเจต ทัศนียานนท์</p>
                          <p>ปีงบประมาณ ปี2017 100ล้าน </p>
                          <p><a href="view.html"><button type="button">View</button></a><a href="file:///E:/testhtml/edit.html"><button>Edit</button></a><button onclick="d()">delete</button></p>
                        </div>
                        <div class="card">
                          <h1>โครงการบ้านนี้มีรัก</h1>
                          <p>หัวหน้าโครงการ นาย ธีรเจต ทัศนียานนท์</p>
                          <p>ปีงบประมาณ ปี2017 100ล้าน </p>
                          <p><a href="view.html"><button type="button">View</button></a><a href="file:///E:/testhtml/edit.html"><button>Edit</button></a><button onclick="d()">delete</button></p>
                        </div>
                        <div class="card">
                          <h1>โครงการบ้านนี้มีรัก</h1>
                          <p>หัวหน้าโครงการ นาย ธีรเจต ทัศนียานนท์</p>
                          <p>ปีงบประมาณ ปี2017 100ล้าน </p>
                          <p><a href="view.html"><button type="button">View</button></a><a href="file:///E:/testhtml/edit.html"><button>Edit</button></a><button onclick="d()">delete</button></p>
                        </div>
                        <div class="aa">
                          <br><a href="tarhtml.html" class="btn btn-danger"> Previous</a>
                          <a href="next.html" class="btn btn-danger" >Next </a>
                        </div>
                      </article>



                    </div>

                  </div>
                </div>
                <div class="col-sm-2 sidenav"></div>
            </div>
        </div>
    
        @endsection
    @section('footer')
  
    @endsection
  