
  
@extends('layouts.ProjectandService_app')
@section('content')


        <div class="container-fluid ">
            <div class="row content">
                <div class="col-sm-2 sidenav">
                <h4>
                <p><a href="./moufirst">หน้าแรกระบบ</a><br></p>
            </h4>
       
                </div>



                <div class="col-sm-8 main">
                  <div class="w3-row w3-padding-64">
                    <div class="w3-twothird w3-container">
                      <h1 class="w3-text-teal">ระบบได้ทำการเพิ่มข้อมูลเรียบร้อยแล้ว</h1> <br>
                      <br><br>
                      <a href="moufirst.html"><input type="button" value="กลับสู่หน้าแรก" class="btn btn-default"></a>

                    </div>

                  </div>
                </div>
                <div class="col-sm-2 sidenav"></div>
            </div>
        </div>
    
    @endsection
    @section('footer')
   
    @endsection

