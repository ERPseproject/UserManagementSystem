@extends('layouts.Service_app')
@section('content')



<div class="container-fluid ">
  <div class="row content">
    <div class="col-sm-2 sidenav">
      <h4>
        <p><a href="./moufirst">หน้าแรกระบบ</a><br></p>
      </h4>
      <h5>
        <p><a href="search_service"> Search page</a></p>
      </h5>
      <h5>
        <p><a href="service_view"> viewdata page</a></p>
      </h5>
    </div>



    <div class="col-sm-9">
      <div class="w3-row w3-padding-64">
        <div class="w3-twothird w3-container">
          <h1 class="w3-text-teal">ดูรายละเอียดโครงการ</h1>
          <div class="topnav">
            <a class="active"></a>
            <section>
              <form>
                <article>
                  <table id="customers">
                    <tr>
                      <th>โครงการ</th>
                      <th>ชื่อผู้รับผิดชอบ</th>
                      <th>เลขกำกับโครงการ</th>
                      <th>MOU/OPEN</th>
                      <th>ชื่อผู้รับบริการ</th>
                      <th>งบประมาณทั้งหมดที่มี</th>
                      <th>เอกสาร</th>
                      <th>วันเริ่มเปิดโครงการ</th>
                      <th>วันที่ปิดโครงการ</th>
                      <th>ปีที่ได้รับงบประมาณ</th>
                      <th>จำนวนเงินรวมรายปี</th>
                    </tr>
                    <tr>
                      <td>โครงการ a</td>
                      <td>นาย a</td>
                      <td>007</td>
                      <td>OPEN</td>
                      <td>นาย b</td>
                      <td>10</td>
                      <td>รายงานโครงการ a</td>
                      <td>25/1/65</td>
                      <td>25/2/69</td>
                      <td>2065</td>
                      <td>-</td>
                    </tr>

                  </table>
                </article>

              </form>
          </div>
        </div>



      </div>
    </div>


  </div>
</div>

@endsection
@section('footer')

@endsection