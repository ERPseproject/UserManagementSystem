@extends('layouts.app2')

@section('content')
<!--Main Content-->
    
<div class="main">
        <div class="container-fluid text-center">
            <!--Side Menu-->
            <div class="row content">
                <div class="col-sm-2 sidenav">
                </div>
                <!--Main Menu-->
                <div class="col-sm-8">
                    <h1>ระบบคุรุภัณฑ์</h1>
                    <form action="./add">
                    <button  type="submit" style ="height: 50px; width: 200px" class="btn btn-default">เพิ่มคุรุภัณฑ์</button>
                    </form>  
                    <br />
                    <form action="./search">
                    <button type="submit" style ="height: 50px; width: 200px" class="btn btn-default">ค้นหา/จำหน่ายออกคุรุภัณฑ์</button>
                    </form> 
                    <br />
                    <form action="./addrec">
                    <button type="submit" style ="height: 50px; width: 200px" class="btn btn-default">รายการเพิ่มคุรุภัณฑ์</button>
                    </form>
                    <br />
                    <form action ="./soldrec">
                    <button type="submit" style ="height: 50px; width: 200px"class="btn btn-default">รายการจำหน่ายออกคุรุภัณฑ์</button>
                    <br />
                    </form>
                </div>
                <div class="col-sm-2 sidenav"></div>
            </div>
        </div>
    </div>
@endsection
@section('footer')

@endsection