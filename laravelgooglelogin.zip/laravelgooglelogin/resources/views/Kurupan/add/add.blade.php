@extends('layouts.Kurupan_app')

@section('content')


    <!--Main Content-->
    
      <div class="container-fluid text-center">
      <!--Side Menu-->
        <div class="row content">
          <!--sidebar-->
          <div class="col-sm-2 sidenav"> 
              <a href="./kurupan">ระบบคุรุภัณฑ์</a>
          </div>
          <div class="col-sm-8 main ">
                <!--input add-->
          <h3 class="w3-text-teal">เพิ่มคุรุภัณฑ์</h3>
          <br>
          <form action="{{ url('/home/add/saveadd') }}" id="form" method="post">
	        <input type="hidden" name="_token" value="{{ csrf_token() }}">
            <div class="Name">
                ชื่อคุรุภัณฑ์: <input placeholder="old data" type="text" name="name">
                <br>
            </div>
            <br />
            <div class="ItemId">
                รหัสคุรุภัณฑ์: <input type="text" name="itemid">
                <br>
            </div>
            <br />
            <div class="StateOfBuying">
                สถานะการจัดซื้อ: <input type="text" name="stateofbuying">
                <br>
            </div>
            <br />
            <div class="DateToBuy">
                วันที่จัดซื้อ: <input type="text" name="datetobuy">
                <br>   
            </div>
            <br />
            <div class="Price">
                ราคา : <input type="text" name="price">
                <br>
            </div>
            <br />
            <div class="ResponsiblePerson">
                ผู้รับผิดชอบ : <input  type="text" name="responsibleperson">
                <br>
            </div>
            <br />
            <div class="DateToSell">
                วันจำหน่ายออก : <input type="text" name="datetosell">
                <br>
            </div>
            <br />
            <div class ="picture">
                รูปภาพ :<input type="text" name =" picture">
                <br>
            </div>
            <div class="Room">
              ตำแหน่งที่ตั้ง :<input list="room" name ="room">
                <datalist id="room">
                    <?php
                    for ($i=0;$i<4;$i++){
                        ?>
                  <option value=<?php echo(1111*($i+1)) ?>>

                  <?php
                    }
                    ?>
                </datalist>
            </div>
          <br />
          <br />
          <br />
          <br />
          <br />
          <div class="menu button">
            <button type="submit" form="form" class="btn btn-outline-success">บันทึก</button>
            <button type="submit" class="btn btn-outline-danger"><a href="/home">ยกเลิก</a></button>
            <button type="button" class="btn btn-outline-warning">แก้ไข</button>
          </div>
                            
        </form>
      </div>
      <div class="col-sm-2 sidenav"></div>
</div>
        
  </div>
              

    @endsection
    @section('footer')
   
    @endsection



    