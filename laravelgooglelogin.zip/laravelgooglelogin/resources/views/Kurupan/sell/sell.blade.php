@extends('layouts.Kurupan_app')
@section('content')

    <!--input not correct-->
    <script>
        var msg = '{{Session::get('alert')}}';
        var exist = '{{Session::has('alert')}}';
        if(exist){
            alert(msg);
        }
    </script>
  

    <!--Main Content-->
 
        <div class="container-fluid text-center">
        <!--Side Menu-->
            <div class="row content">
            <!--sidebar-->
            <div class="col-sm-2 sidenav"> 
                <a href="/home">ระบบคุรุภัณฑ์</a>
            </div>
            <!--input add-->
            <div class="col-sm-8 main"> 
            <h3 class="w3-text-teal">จำหน่ายออกคุรุภัณฑ์{{$itemid}}</h3>
            <br>
            <form action="{{ url('/home/sell/'.$itemid) }}" id="form" method="post">
	        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <div class="datetosell">
                    วันจำหน่ายออก:<input placeholder=" " type="text" name="datetosell">
                    <br>
                </div>
            <br />
                <div class="buyer">
                    ผู้รับซื้อ:<input placeholder=" " type="text" name="buyer">
                    <br />
                </div>
                <br />
                <div class="menu button">
                    <button type="submit" form="form" class="btn btn-outline-success">บันทึก</button>
                    <button type="submit" class="btn btn-outline-danger"><a href="/home">ยกเลิก</a></button>
                </div>
            </form>
            </div>
        </div>
        <div class="col-sm-2 sidenav"> </div>
        </div>
        @endsection
    @section('footer')

    @endsection
